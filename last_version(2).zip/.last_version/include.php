<?php
/**
 * PayParts Payment Module
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category        PayParts
 * @package         privatbank.paymentparts
 * @version         0.0.1
 * @author          PayParts
 * @copyright       Copyright (c) 2015 PayParts
 * @license         http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 *
 * EXTENSION INFORMATION
 *
 * 1C-Bitrix        15.0
 * PAYPARTS API       https://payparts2.privatbank.ua/ipp/
 *
 */